// Hold application secrets and config
module.exports = {
    secret: 'thisissecret12345'
};